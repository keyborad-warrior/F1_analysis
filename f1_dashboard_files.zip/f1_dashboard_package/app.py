import os

import kagglehub
import pandas as pd
import plotly.express as px
import streamlit as st


DATASET = "rohanrao/formula-1-world-championship-1950-2020"

st.set_page_config(
    page_title="Formula 1 Dashboard",
    page_icon="🏎️",
    layout="wide"
)


@st.cache_data(show_spinner=True)
def load_data():
    """Download and load the Kaggle F1 dataset."""
    path = kagglehub.dataset_download(DATASET)

    def read_csv(name):
        return pd.read_csv(os.path.join(path, name), na_values="\\N")

    drivers = read_csv("drivers.csv")
    results = read_csv("results.csv")
    races = read_csv("races.csv")
    constructors = read_csv("constructors.csv")
    pit_stops = read_csv("pit_stops.csv")

    # Clean common numeric columns. Because CSVs love pretending numbers are strings.
    results["positionOrder"] = pd.to_numeric(results["positionOrder"], errors="coerce")
    results["points"] = pd.to_numeric(results["points"], errors="coerce").fillna(0)
    results["grid"] = pd.to_numeric(results["grid"], errors="coerce")
    pit_stops["duration"] = pd.to_numeric(pit_stops["duration"], errors="coerce")
    races["year"] = pd.to_numeric(races["year"], errors="coerce")

    drivers["driverName"] = (
        drivers["forename"].fillna("") + " " + drivers["surname"].fillna("")
    ).str.strip()

    race_cols = ["raceId", "year", "round", "name", "circuitId"]
    result_data = (
        results
        .merge(drivers[["driverId", "driverName", "nationality"]], on="driverId", how="left")
        .merge(constructors[["constructorId", "name"]].rename(columns={"name": "constructorName"}),
               on="constructorId", how="left")
        .merge(races[race_cols].rename(columns={"name": "raceName"}), on="raceId", how="left")
    )

    pit_data = (
        pit_stops
        .merge(drivers[["driverId", "driverName"]], on="driverId", how="left")
        .merge(races[["raceId", "year", "name"]].rename(columns={"name": "raceName"}),
               on="raceId", how="left")
    )

    return result_data, pit_data, races, drivers, constructors


result_data, pit_data, races, drivers, constructors = load_data()

st.title("🏎️ Formula 1 Dashboard")
st.write("A simple interactive dashboard using the Kaggle Formula 1 World Championship dataset.")

min_year = int(result_data["year"].min())
max_year = int(result_data["year"].max())

with st.sidebar:
    st.header("Filters")
    year_range = st.slider(
        "Select season range",
        min_value=min_year,
        max_value=max_year,
        value=(max(2010, min_year), max_year)
    )
    top_n = st.slider("Top records to show", 5, 25, 10)

filtered_results = result_data[
    result_data["year"].between(year_range[0], year_range[1])
].copy()
filtered_pits = pit_data[
    pit_data["year"].between(year_range[0], year_range[1])
].copy()

col1, col2, col3, col4 = st.columns(4)
col1.metric("Seasons", filtered_results["year"].nunique())
col2.metric("Races", filtered_results["raceId"].nunique())
col3.metric("Drivers", filtered_results["driverId"].nunique())
col4.metric("Pit Stops", len(filtered_pits))

st.divider()

left, right = st.columns(2)

with left:
    st.subheader("Top Drivers by Wins")
    wins = (
        filtered_results[filtered_results["positionOrder"] == 1]
        .groupby("driverName")
        .size()
        .reset_index(name="Wins")
        .sort_values("Wins", ascending=False)
        .head(top_n)
    )
    fig = px.bar(wins, x="driverName", y="Wins", title="Race Wins by Driver")
    fig.update_layout(xaxis_title="Driver", yaxis_title="Wins")
    st.plotly_chart(fig, use_container_width=True)

with right:
    st.subheader("Top Constructors by Wins")
    constructor_wins = (
        filtered_results[filtered_results["positionOrder"] == 1]
        .groupby("constructorName")
        .size()
        .reset_index(name="Wins")
        .sort_values("Wins", ascending=False)
        .head(top_n)
    )
    fig = px.bar(constructor_wins, x="constructorName", y="Wins", title="Race Wins by Constructor")
    fig.update_layout(xaxis_title="Constructor", yaxis_title="Wins")
    st.plotly_chart(fig, use_container_width=True)

st.divider()

left, right = st.columns(2)

with left:
    st.subheader("Average Pit Stop Duration by Year")
    pit_by_year = (
        filtered_pits.dropna(subset=["duration"])
        .groupby("year", as_index=False)["duration"]
        .mean()
        .rename(columns={"duration": "Average Duration Seconds"})
    )
    fig = px.line(
        pit_by_year,
        x="year",
        y="Average Duration Seconds",
        markers=True,
        title="Pit Stop Speed Trend"
    )
    fig.update_layout(xaxis_title="Year", yaxis_title="Avg duration in seconds")
    st.plotly_chart(fig, use_container_width=True)

with right:
    st.subheader("Driver Points")
    driver_points = (
        filtered_results
        .groupby("driverName", as_index=False)["points"]
        .sum()
        .sort_values("points", ascending=False)
        .head(top_n)
    )
    fig = px.bar(driver_points, x="driverName", y="points", title="Total Points by Driver")
    fig.update_layout(xaxis_title="Driver", yaxis_title="Points")
    st.plotly_chart(fig, use_container_width=True)

st.divider()

st.subheader("Fastest Pit Stops")
fastest_pits = (
    filtered_pits.dropna(subset=["duration"])
    .sort_values("duration")
    .loc[:, ["year", "raceName", "driverName", "stop", "lap", "duration"]]
    .head(top_n)
)
st.dataframe(fastest_pits, use_container_width=True, hide_index=True)

st.subheader("Race Result Data")
show_cols = [
    "year", "raceName", "driverName", "constructorName",
    "grid", "positionOrder", "points"
]
st.dataframe(
    filtered_results[show_cols].sort_values(["year", "raceName", "positionOrder"]),
    use_container_width=True,
    hide_index=True
)
